package com.yash.lifeos

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context

object WidgetUpdater {
    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        NextActionWidgetProvider.update(
            context, manager,
            manager.getAppWidgetIds(ComponentName(context, NextActionWidgetProvider::class.java))
        )
        ScreenTimeWidgetProvider.update(
            context, manager,
            manager.getAppWidgetIds(ComponentName(context, ScreenTimeWidgetProvider::class.java))
        )
        FocusWidgetProvider.update(
            context, manager,
            manager.getAppWidgetIds(ComponentName(context, FocusWidgetProvider::class.java))
        )
    }
}
