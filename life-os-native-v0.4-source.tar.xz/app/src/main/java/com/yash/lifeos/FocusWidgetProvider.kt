package com.yash.lifeos

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

class FocusWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)

    companion object {
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val repo = LifeRepository(context)
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_focus)
                if (repo.isFocusActive()) {
                    views.setTextViewText(R.id.widgetFocusStatus, repo.focusLabel())
                    views.setViewVisibility(R.id.widgetFocusChronometer, View.VISIBLE)
                    views.setViewVisibility(R.id.widgetFocusAction, View.VISIBLE)
                    val left = (repo.focusEnd() - System.currentTimeMillis()).coerceAtLeast(0L)
                    val base = SystemClock.elapsedRealtime() + left
                    views.setChronometer(R.id.widgetFocusChronometer, base, null, true)
                    views.setChronometerCountDown(R.id.widgetFocusChronometer, true)
                    views.setTextViewText(R.id.widgetFocusAction, "OPEN")
                    views.setOnClickPendingIntent(R.id.widgetFocusAction, openIntent(context, "focus", id + 40_000))
                } else {
                    views.setTextViewText(R.id.widgetFocusStatus, "Ready for ${repo.focusDefaultMin()} minutes?")
                    views.setViewVisibility(R.id.widgetFocusChronometer, View.GONE)
                    views.setTextViewText(R.id.widgetFocusAction, "START ${repo.focusDefaultMin()}")
                    views.setOnClickPendingIntent(R.id.widgetFocusAction, openIntent(context, "focusDefault", id + 40_000))
                }
                views.setOnClickPendingIntent(R.id.widgetFocusStatus, openIntent(context, "focus", id + 50_000))
                manager.updateAppWidget(id, views)
            }
        }

        private fun openIntent(context: Context, action: String, request: Int): PendingIntent {
            return PendingIntent.getActivity(
                context, request,
                Intent(context, MainActivity::class.java).putExtra("action", action),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
