package com.yash.lifeos

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class NextActionWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)

    companion object {
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val repo = LifeRepository(context)
            val next = PlannerEngine(repo).build().next
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_next_action)
                views.setTextViewText(R.id.widgetTask, next?.title ?: "Nothing urgent")
                views.setTextViewText(R.id.widgetMeta, next?.area ?: "Use the space intentionally")
                views.setTextViewText(R.id.widgetNextTime, next?.let { "${it.durationMin}m" } ?: "—")
                views.setViewVisibility(R.id.widgetStart, if (next == null) android.view.View.GONE else android.view.View.VISIBLE)
                views.setOnClickPendingIntent(R.id.widgetTask, openIntent(context, "today", id))
                views.setOnClickPendingIntent(R.id.widgetMeta, openIntent(context, "today", id + 10_000))
                if (next != null) views.setOnClickPendingIntent(R.id.widgetStart, openIntent(context, "focusNext", id + 20_000))
                manager.updateAppWidget(id, views)
            }
        }

        private fun openIntent(context: Context, action: String, request: Int): PendingIntent {
            val i = Intent(context, MainActivity::class.java).putExtra("action", action)
            return PendingIntent.getActivity(context, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
    }
}
