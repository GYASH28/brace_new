package com.yash.lifeos

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class ScreenTimeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)

    companion object {
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val repo = LifeRepository(context)
            val usage = UsageStatsRepository(context, repo)
            val snapshot = if (usage.hasPermission()) usage.todaySnapshot(force = true) else null
            val goal = repo.screenGoalMin() * 60_000L
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_screen_time)
                views.setTextViewText(R.id.widgetScreenGoal, "goal ${UsageStatsRepository.formatDuration(goal)}")
                if (snapshot != null) {
                    views.setTextViewText(R.id.widgetScreenTotal, UsageStatsRepository.formatDuration(snapshot.totalMs))
                    val top = snapshot.topDistracting
                    val meta = if (top != null) "${top.label} • ${UsageStatsRepository.formatDuration(top.foregroundMs)} distracting" else "No major distraction pattern yet"
                    views.setTextViewText(R.id.widgetScreenMeta, meta)
                    views.setProgressBar(R.id.widgetScreenProgress, 100, ((snapshot.totalMs * 100 / goal.coerceAtLeast(1L)).toInt()).coerceIn(0, 100), false)
                } else {
                    views.setTextViewText(R.id.widgetScreenTotal, "Connect")
                    views.setTextViewText(R.id.widgetScreenMeta, "Tap to grant Usage Access")
                    views.setProgressBar(R.id.widgetScreenProgress, 100, 0, false)
                }
                val i = Intent(context, MainActivity::class.java).putExtra("action", "insights")
                val pi = PendingIntent.getActivity(context, id + 30_000, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.widgetScreenTotal, pi)
                views.setOnClickPendingIntent(R.id.widgetScreenMeta, pi)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
